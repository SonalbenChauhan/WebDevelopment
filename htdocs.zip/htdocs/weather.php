<html>
    <head>
    

<link rel="stylesheet" type="text/css" href="weather.css">
    </head>
    <body>
<?php

$city = $_GET['city'];
        
   $url = "https://api.openweathermap.org/data/2.5/weather?q=" . $city .
       "&units=metric&appid=00109f8685940ca98ab90990cac85a40";

        

$jsonString = file_get_contents($url);
$jsonArray = json_decode($jsonString, true);
?>

<table border="1"> <caption><h3>Today's Weather</h3></caption>
  
  
<tr>
    <th> Country Name</th>
    <th>Temperature</th>
    <th> Wind Speed</th>
    <th> Climate</th>
    
 
    </tr>
    <tr>
        
   <td>
<?php echo $jsonArray['name'];
       
    ?>
       </td>
      <td>
<?php echo $jsonArray['main'] ['temp_min']; 
    ?>
       </td>
     
      <td>
<?php echo $jsonArray['wind']  ['speed']; 
    ?>
       </td>
      
 
    
           <td>
<?php echo $jsonArray['weather'] [0] ['main']; 
    ?>
       </td>
 
        
        

</tr>
    </table>
</body>   

    </html>


