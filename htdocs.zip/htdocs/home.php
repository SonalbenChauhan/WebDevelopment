<html>
<head>
    

    <h1>Please enter the name of the city</h1>
    <link rel="stylesheet" type="text/css" href="weather.css">
    </head>
    <body>
        <form action="weather.php">
           
    <label>Name of the city </label>
    <input type="text" name="city" required> 
                
    <input type="submit" value="submit"/>
                
            </form>
    </body>
    
</html>