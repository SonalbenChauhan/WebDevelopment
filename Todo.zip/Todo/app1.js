function add()
{
	//alert("the add button was pressed");
	
	//grab the text inside bthe textbox
	var text = document.getElementById("new-item").value;
	
	if(text.length != 0){
	//create a new element of type list
	var listElement = document.createElement("li");
	
	//create a tec=xt node that includes the text from the input box
	var textNode = document.createTextNode(text);
	
	// create new remove button
	var removeButton = document.createElement("a");
	removeButton.innerHTML = "<i class='far fa-times-circle'></i>";
			
	// add a onclick event handler
	removeButton.onclick = function(){
		removeButton.parentElement.remove();
	}
		
	//append the text and remove button to the list element
	listElement.appendChild(textNode);
	listElement.appendChild(removeButton);
	
	//append the list element to the #todo-list
	document.getElementById("todo-list").appendChild(listElement);
	
	//clear the text box
		document.getElementById("new-item").value = "";
	//alert(text);
	}
}