function validateEmail(email) 
{
    var mail = /^([A-Za-z0-9_-.])+@+([conestogac])+.+([on])+.+([ca])$/;
    if (mail.test(email))
    {
        return (true);
    }
        alert("You have entered an invalid email address!");
        return false;
}