function myFunction()
{
    document.getElementById("myForm").reset();
}

function validateForm() {
  var x = document.forms["myForm"]["fname"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
}
function check() {
    if(document.getElementById('Pass').value ===
            document.getElementById('Pass1').value) {
        alert("Match");
    } else {
        alert("UnMatch");;
        
    }
}

