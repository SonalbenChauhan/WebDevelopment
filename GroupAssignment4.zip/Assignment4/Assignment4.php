<!DOCTYPE html>
<html>
<head>
    <title>Count string</title>
    <style>
        form{}
        body {background-color: #b3b3ff;}
        h1{background-color: cornflowerblue;}
        div {text-align: center;}
        table {background-color: #6666ff; text-align: center;}
    </style>
    
<body>
<div>
    <p><h1><strong>Counting the number of words repeated...</h1></strong></p>
    
<form action="Assignment4.php" method="get">
    <label><h3>Enter the string here </h3></label>
    <input name="string" type="text">
    <input type="submit"><br><br>
    </form>    
     
<?php
    $str = strtolower($_GET["string"]);
    countWord($str);
    $varOutput=array();
    
    function countWord($strWord){
    $varArray=explode(" ",$strWord);
    foreach ($varArray as $string){
        if (in_array($string,$varArray)) {
            if(isset($varOutput[$string])){
                $varOutput[$string]+=1;
            }else{
                $varOutput[$string]=1;
            }
        }
    }    
    arsort($varOutput);
    print_r($varOutput);
        
    echo "<table border='1' align='center'>";
    echo "<tr><th>Word</th><th>Count</th></tr>";
    foreach ($varOutput as $word => $count){
        echo "<tr>";
        echo "<td>", $word, "</td>";
        echo "<td>", $count, "</td>";
        echo "</tr>";
    }
    echo"</table>";
    }
?>
     </div>
</body>    
</head>    
</html>