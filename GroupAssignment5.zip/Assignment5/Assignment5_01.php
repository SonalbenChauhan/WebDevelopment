<?php
session_start();
if (isset($_POST['usernameGet']))
{
    $_SESSION['usernameGet'] = $_POST['usernameGet'];
 echo $_SESSION['usernameGet'];
}
?>

