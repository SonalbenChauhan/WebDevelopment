<html>
<head>
    </head>
    <body>
    <link rel="stylesheet" href="product.css">
        <div class="head-nav">
                <nav>
                     <a href="Assignment5.php"> Home </a> &nbsp;
                       <div class="right-nav">
                           <span><?php if (isset($_SESSION['usernameGet'])){ echo "Logged in as ". $_SESSION['usernameGet']; }?></span>
                            <a href="product1.php">Product1</a>
                            <a href="Product2.php">Product2</a>  
                            <a href="Product3.php">Product3</a>
                           <a href="logout.php">log out</a>
                        </div>
                </nav>
            </div>
        <br><br>
<form method="post" action="product1.php">
    
    <label>Please Enter your name here: </label>
    <input type="text" name="usernameGet" placeholder="Your name is ">
    <input type="submit" value="submit" name="submit">
</form>   
         
    </body>
</html>




        
        
        
        
    