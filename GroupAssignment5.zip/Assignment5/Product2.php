<!DOCTYPE html>
<html>
<head>
    <title>Product 2</title>
    <link rel="stylesheet" href="product.css">
    </head>
    
    <body>
          <?php
session_start();
if (isset($_POST['usernameGet']))
{
    $_SESSION['usernameGet'] = $_POST['usernameGet'];
}
if (isset($_POST['item4']))
{
    $_SESSION['item4'] = $_POST['item4'];
}
        if (isset($_POST['item5']))
{
    $_SESSION['item5'] = $_POST['item5'];
}
        if (isset($_POST['item6']))
{
    $_SESSION['item6'] = $_POST['item6'];
}


?>
        <div class="head-nav">
                <nav>
                     <a href="Assignment5.php"> Home </a> &nbsp;
                       <div class="right-nav">
                           <span><?php if (isset($_SESSION['usernameGet'])){ echo "Logged in as". $_SESSION['usernameGet']; }?></span>
                            <a href="product1.php">Product1</a>
                            <a href="Product2.php">Product2</a>  
                            <a href="Product3.php">Product3</a>
                           <a href="logout.php">log out</a>
                        </div>
                </nav>
            </div>
        <form align="center" action="product2.php" method="post"> 
        <u><h2 align="center" style="color:White">Cosmetics Products page 2</h2></u>
            <br>
            <br>
        <label >Item 4</label>
        <img src="FullMeasure_VanillaFudge.jpg" alt="Makeup Kit" width="15%" height="7%">
       <input type="text" name="item4" placeholder="Quantity" value="<?php if (isset($_SESSION['item4'])){ echo $_SESSION['item4']; }?>">
    <input type="submit" value="submit" name="submit">
</form>  
        <form align="center" action="product2.php" method="post"> 
            <br>
            <br>
        <label >Item 5</label>
        <img src="High_Def_Powder_2_large.jpg" alt="Makeup Kit" width="15%" height="7%">
       <input type="text" name="item5" placeholder="Quantity" value="<?php if (isset($_SESSION['item5'])){ echo $_SESSION['item5']; }?>">
    <input type="submit" value="submit" name="submit">
        </form>  
        <form align="center" action="product2.php" method="post">     
             <br>
            <br>
        <label >Item 6</label>
        <img src="concealer_tonoscosmetic_1.jpg" alt="Makeup Kit" width="15%" height="7%">
        <input type="text" name="item6"placeholder="Quantity" value="<?php if (isset($_SESSION['item6'])){ echo $_SESSION['item6']; }?>">
    <input type="submit" value="submit" name="submit">
</form>  
       
        
        
    </body>
    
</html>