<!DOCTYPE html>
<html>
<head>
    <title>Product 3</title>
    <link rel="stylesheet" href="product.css">
    </head>
    
    <body>
                 <?php
session_start();
if (isset($_POST['usernameGet']))
{
    $_SESSION['usernameGet'] = $_POST['usernameGet'];
}
if (isset($_POST['item7']))
{
    $_SESSION['item7'] = $_POST['item7'];
}
        if (isset($_POST['item8']))
{
    $_SESSION['item8'] = $_POST['item8'];
}
        if (isset($_POST['item9']))
{
    $_SESSION['item9'] = $_POST['item9'];
}


?>
        <div class="head-nav">
                <nav>
                     <a href="Assignment5.php"> Home </a> &nbsp;
                       <div class="right-nav">
                           <span><?php if (isset($_SESSION['usernameGet'])){ echo "Logged in as". $_SESSION['usernameGet']; }?></span>
                            <a href="product1.php">Product1</a>
                            <a href="Product2.php">Product2</a>  
                            <a href="Product3.php">Product3</a>
                           <a href="logout.php">log out</a>
                        </div>
                </nav>
            </div>
        <form align="center" action="product3.php" method="post"> 
        
        <u><h2 align="center" style="color:White">Cosmetics Products page 3</h2></u>
            <br>
            <br>
        <label >Item 7</label>
        <img src="images%20(4).jpg" alt="Makeup Kit" width="15%" height="7%">
        <input type="text" name="item7" placeholder="Quantity" value="<?php if (isset($_SESSION['item7'])){ echo $_SESSION['item7']; }?>">
    <input type="submit" value="submit" name="submit">
</form>  
        <form align="center" action="product3.php" method="post"> 
            <br>
            <br>
        <label >Item 8</label>
        <img src="images%20(6).jpg" alt="Makeup Kit" width="15%" height="7%">
         <input type="text" name="item8" placeholder="Quantity" value="<?php if (isset($_SESSION['item8'])){ echo $_SESSION['item8']; }?>">
    <input type="submit" value="submit" name="submit">
</form>  
        <form align="center" action="product3.php" method="post"> 
             <br>
            <br>
        <label >Item 9</label>
        <img src="images%20(7).jpg" alt="Makeup Kit" width="15%" height="7%">
        <input type="text" name="item9" placeholder="Quantity" value="<?php if (isset($_SESSION['item9'])){ echo $_SESSION['item9']; }?>">
    <input type="submit" value="submit" name="submit">
</form>
    </body>
    
</html>